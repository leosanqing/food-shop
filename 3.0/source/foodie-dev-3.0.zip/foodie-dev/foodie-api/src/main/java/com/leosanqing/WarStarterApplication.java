package com.leosanqing;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * @Author: leosanqing
 * @Date: 2019/12/22 下午10:32
 * @Package: com.leosanqing
 * @Description: War包的启动类
 */

//public class WarStarterApplication extends SpringBootServletInitializer {
//    @Override
//    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
//        return builder.sources(Application.class);
//    }
//}
