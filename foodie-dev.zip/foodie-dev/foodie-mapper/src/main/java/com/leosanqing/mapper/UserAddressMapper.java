package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.UserAddress;

public interface UserAddressMapper extends MyMapper<UserAddress> {
}