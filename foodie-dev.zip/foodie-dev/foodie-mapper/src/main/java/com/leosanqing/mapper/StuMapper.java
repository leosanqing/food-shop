package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.Stu;

public interface StuMapper extends MyMapper<Stu> {
}