package com.leosanqing.controller;

/**
 * @Author: leosanqing
 * @Date: 2020/1/15 下午11:10
 * @Package: com.leosanqing.controller
 * @Description:
 */
public class BaseController {
    public static final String SHOP_CART = "shopcart";
    public static final String  REDIS_USER_TOKEN = "redis_user_token";
}
