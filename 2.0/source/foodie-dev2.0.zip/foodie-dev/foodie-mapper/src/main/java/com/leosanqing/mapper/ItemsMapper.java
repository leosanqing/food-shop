package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.Items;

public interface ItemsMapper extends MyMapper<Items> {
}