package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.Users;

public interface UsersMapper extends MyMapper<Users> {
}