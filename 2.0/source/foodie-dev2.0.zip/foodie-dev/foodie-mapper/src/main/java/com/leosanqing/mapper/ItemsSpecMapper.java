package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.ItemsSpec;

public interface ItemsSpecMapper extends MyMapper<ItemsSpec> {
}