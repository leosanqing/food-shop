package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.Carousel;

public interface CarouselMapper extends MyMapper<Carousel> {
}