package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.OrderStatus;

public interface OrderStatusMapper extends MyMapper<OrderStatus> {
}