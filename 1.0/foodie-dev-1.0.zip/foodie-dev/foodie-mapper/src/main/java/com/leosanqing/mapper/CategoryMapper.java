package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.Category;

public interface CategoryMapper extends MyMapper<Category> {
}