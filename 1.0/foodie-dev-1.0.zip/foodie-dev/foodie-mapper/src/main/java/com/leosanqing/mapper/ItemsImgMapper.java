package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.ItemsImg;

public interface ItemsImgMapper extends MyMapper<ItemsImg> {
}