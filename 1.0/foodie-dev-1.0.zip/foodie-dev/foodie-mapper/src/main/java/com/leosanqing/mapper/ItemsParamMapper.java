package com.leosanqing.mapper;

import com.leosanqing.my.mapper.MyMapper;
import com.leosanqing.pojo.ItemsParam;

public interface ItemsParamMapper extends MyMapper<ItemsParam> {
}